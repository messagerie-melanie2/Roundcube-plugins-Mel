OC.L10N.register(
    "files",
    {
    "Unknown error" : "Hindi kilalang error",
    "Close" : "Isara",
    "Download" : "I-download",
    "Details" : "Mga Detalye",
    "New folder" : "Bagong folder",
    "Upload" : "Mag-upload"
},
"nplurals=2; plural=(n > 1);");
