OC.L10N.register(
    "files",
    {
    "Unshare" : "Deel terug neem",
    "Folder" : "Omslag",
    "Settings" : "Instellings"
},
"nplurals=2; plural=(n != 1);");
